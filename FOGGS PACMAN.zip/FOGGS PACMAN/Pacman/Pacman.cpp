#include "Pacman.h"

#include <sstream>
#include <time.h>

Pacman::Pacman(int argc, char* argv[]) : Game(argc, argv), _cPacmanSpeed(0.1f), _cPacmanFrameTime(250), _cMunchieFrameTime(750)
{
	int i{};

	_pacman = new Player();
	_munchie[i] = new Enemy();
	_ghosts[i] = new MovingEnemy();
	_menu = new MenuStruct();
	_cherry = new CherryStruct();

	srand(time(NULL));

	for (i = 0; i < MUNCHIECOUNT; i++)
	{
		_munchie[i] = new Enemy();
		_munchie[i]->FrameCount = rand() % 2;
		_munchie[i]->CurrentFrameTime = 0;
		_munchie[i]->Frame = rand() % 500 + 50;
	}
	
	Texture2D* munchieTex = new Texture2D();
	munchieTex->Load("munchieSpriteSheet.png", false);

	for (i = 0; i < MUNCHIECOUNT; i++)
		_munchie[i]->Texture = munchieTex;

	_pacman->dead = false;
	_pacman->Direction = 0;
	_pacman->CurrentFrameTime = 0;
	_pacman->Frame = 0;
	_pacman->speedMultiplier = 1.0f;

	_munchie[i]->FrameCount = 0;
	_munchie[i]->CurrentFrameTime = 0;

	_paused = false;
	_startScreen = true;
	_pKeyDown = false;
	_score = 0;
	
	for (int i = 0; i < GHOSTCOUNT; i++)
	{
		_ghosts[i] = new MovingEnemy();
		_ghosts[i]->Direction = 0;
		_ghosts[i]->Speed = 0.2f;
	}

	//Initialise important Game aspects
	Graphics::Initialise(argc, argv, this, 1024, 768, false, 25, 25, "Pacman", 60);
	Input::Initialise();

	// Start the Game Loop - This calls Update and Draw in game loop
	Graphics::StartGameLoop();
}

//Destructor Method
Pacman::~Pacman()
{
	delete _pacman->Texture;
	delete _pacman->SourceRect;
	
	delete _munchie[0]->Texture;

	int nCount = 0;
	for (nCount = 0; nCount < MUNCHIECOUNT; nCount++)
	{
		delete _munchie[nCount]->Texture;
		delete _munchie[nCount]->Rect;
		delete _munchie[nCount];
	}
	delete[] _munchie;

	for (nCount = 0; nCount < GHOSTCOUNT; nCount++)
	{
		delete _ghosts[nCount]->Texture;
		delete _ghosts[nCount]->Rect;
		delete _ghosts[nCount];
	}
}

void Pacman::LoadContent()
{
	int i;
	// Load Pacman
	_pacman->Texture = new Texture2D();
	_pacman->Texture->Load("Textures/Pacman.tga", false);
	_pacman->Position = new Vector2(350.0f, 350.0f);
	_pacman->SourceRect = new Rect(0.0f, 0.0f, 32, 32);


	// Load Ghost
	for (i = 0; i < GHOSTCOUNT; i++)
	{
		_ghosts[i]->Texture = new Texture2D();
		_ghosts[i]->Texture->Load("Textures/GhostBlue.png", false);
		_ghosts[i]->Position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
		_ghosts[i]->Rect = new Rect(0.0f, 0.0f, 20, 20);
	}

	// Load Munchie
	for (i = 0; i < MUNCHIECOUNT; i++)
	{
		_munchie[i]->Texture = new Texture2D();
		_munchie[i]->Texture->Load("Textures/munchieSpriteSheet.png", true);
		_munchie[i]->Position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
		_munchie[i]->Rect = new Rect(0.0f, 0.0f, 12, 12);
	}

	// Load Cherry
	
		_cherry->Texture = new Texture2D();
		_cherry->Texture->Load("Textures/Cherry.png", false);
		_cherry->Position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
		_cherry->Rect = new Rect(0.0f, 0.0f, 25, 25);


	
	// Set Menu Parameters
	_menu->Background = new Texture2D();
	_menu->Background->Load("Textures/Transparency.png", false);
	_menu->Rectangle = new Rect(0.0f, 0.0f, Graphics::GetViewportWidth(), Graphics::GetViewportHeight());
	_menu->StringPosition = new Vector2(Graphics::GetViewportWidth() / 2.0f, Graphics::GetViewportHeight() / 2.0f);

	// Set string position
	_stringPosition = new Vector2(10.0f, 25.0f);
}
void Pacman::Input(int elapsedTime, Input::KeyboardState* state, Input::MouseState* mouseState)
{
	float pacmanSpeed = _cPacmanSpeed * elapsedTime * _pacman->speedMultiplier;

	if (state->IsKeyDown(Input::Keys::D) || state->IsKeyDown(Input::Keys::RIGHT))
	{
		_pacman->Position->X += pacmanSpeed;
		_pacman->Direction = 0;
	}

	else if (state->IsKeyDown(Input::Keys::A) || state->IsKeyDown(Input::Keys::LEFT))
	{
		_pacman->Position->X -= pacmanSpeed;
		_pacman->Direction = 2;
	}
	else if (state->IsKeyDown(Input::Keys::W) || state->IsKeyDown(Input::Keys::UP))
	{
		_pacman->Position->Y -= pacmanSpeed;
		_pacman->Direction = 3;
	}

	else if (state->IsKeyDown(Input::Keys::S) || state->IsKeyDown(Input::Keys::DOWN))
	{
		_pacman->Position->Y += pacmanSpeed;
		_pacman->Direction = 1;
	}

	if (state->IsKeyDown(Input::Keys::LEFTSHIFT))
	{
		_pacman->speedMultiplier = 2.0f;
	}
	else if (state->IsKeyUp(Input::Keys::LEFTSHIFT))
	{
		_pacman->speedMultiplier = 1.0f;
	}

	mouseState->LeftButton;

	if (mouseState->LeftButton == Input::ButtonState::PRESSED)
	{
			_cherry->Position->X = mouseState->X;
			_cherry->Position->Y = mouseState->Y;
	}
}
void Pacman::CheckPaused(Input::KeyboardState* state, Input::Keys pauseKey)
{
	if (state->IsKeyDown(Input::Keys::P) && !_pKeyDown)
	{
		_pKeyDown = true;
		_paused = !_paused;
	}
	else if (state->IsKeyUp(Input::Keys::P))
	{
		_pKeyDown = false;
	}
}

void Pacman::CheckViewPortCollision()
{
	if (_pacman->Position->X + _pacman->SourceRect->Width > Graphics::GetViewportWidth())
	{
		_pacman->Position->X = 0 - _pacman->SourceRect->Width;
	}
	if (_pacman->Position->Y + _pacman->SourceRect->Height > Graphics::GetViewportHeight())
	{
		_pacman->Position->Y = 0 - _pacman->SourceRect->Height;
	}
	if (_pacman->Position->X + _pacman->SourceRect->Width < 0)
	{
		_pacman->Position->X = Graphics::GetViewportWidth() - _pacman->SourceRect->Width;
	}
	if (_pacman->Position->Y + _pacman->SourceRect->Height < 0)
	{
		_pacman->Position->Y = Graphics::GetViewportHeight() - _pacman->SourceRect->Height;
	}
}

void Pacman::CheckGhostCollision()
{
	int i = 0;
	int bottom1 = _pacman->Position->Y + _pacman->SourceRect->Height;
	int bottom2 = 0;
	int left1 = _pacman->Position->X;
	int left2 = 0;
	int right1 = _pacman->Position->X + _pacman->SourceRect->Width;
	int right2 = 0;
	int top1 = _pacman->Position->Y;
	int top2 = 0;

	for (i = 0; i < GHOSTCOUNT; i++)
	{
		bottom2 = _ghosts[i]->Position->Y + _ghosts[i]->Rect->Height;
		left2 = _ghosts[i]->Position->X;
		right2 = _ghosts[i]->Position->X + _ghosts[i]->Rect->Width;
		top2 = _ghosts[i]->Position->Y;

		if ((bottom1 > top2) && (top1 < bottom2) && (right1 > left2) && (left1 < right2))
		{
			_pacman->dead = true;
			i = GHOSTCOUNT;
		}
	}
}

void Pacman::CheckMunchieCollision()
{
	int i = 0;
	int bottom1 = _pacman->Position->Y + _pacman->SourceRect->Height;
	int bottom2 = 0;
	int left1 = _pacman->Position->X;
	int left2 = 0;
	int right1 = _pacman->Position->X + _pacman->SourceRect->Width;
	int right2 = 0;
	int top1 = _pacman->Position->Y;
	int top2 = 0;

	for (i = 0; i < MUNCHIECOUNT; i++)
	{
		bottom2 = _munchie[i]->Position->Y + _munchie[i]->Rect->Height;
		left2 = _munchie[i]->Position->X;
		right2 = _munchie[i]->Position->X + _munchie[i]->Rect->Width;
		top2 = _munchie[i]->Position->Y;

		if ((bottom1 > top2) && (top1 < bottom2) && (right1 > left2) && (left1 < right2))
		{
			_munchie[i]->Position->Y = -100;
			_munchie[i]->Position->X = -100;
			_score = _score + 1;
			
			i = MUNCHIECOUNT;
		}
	}
}

void Pacman::UpdatePacman(int elapsedTime)
{
	_pacman->CurrentFrameTime += elapsedTime;
	_pacman->SourceRect->X = _pacman->SourceRect->Width * _pacman->Frame;
	_pacman->SourceRect->Y = _pacman->SourceRect->Height * _pacman->Direction;

	if (_pacman->CurrentFrameTime > _cPacmanFrameTime)
	{
		_pacman->Frame++;

		if (_pacman->Frame >= 2)
			_pacman->Frame = 0;

		_pacman->CurrentFrameTime = 0;
	}

}

void Pacman::UpdateMunchie(Enemy*, int elapsedTime)
{
	int i;
	for (i = 0; i < MUNCHIECOUNT; i++)
	{
		_munchie[i]->CurrentFrameTime += elapsedTime;
		_munchie[i]->Rect->X = _munchie[i]->Rect->Width * _munchie[i]->Frame;

		if (_munchie[i]->CurrentFrameTime > 500)
		{
			_munchie[i]->Frame++;

			if (_munchie[i]->Frame >= 2)
			{
				_munchie[i]->Frame = 0;
			}

			_munchie[i]->CurrentFrameTime = 0;
		}
	}

}

void Pacman::UpdateGhost(MovingEnemy* ghost, int elapsedTime)
{
	if (ghost->Direction == 0)
	{
		ghost->Position->X += ghost->Speed * elapsedTime;
	}
	else if (ghost->Direction == 1)
	{
		ghost->Position->X -= ghost->Speed * elapsedTime;
	}
	if (ghost->Position->X + ghost->Rect->Width >= Graphics::GetViewportWidth())
	{
		ghost->Direction = 1;
	}
	else if (ghost->Position->X <= 0)
	{
		ghost->Direction = 0;
	}
}
void Pacman::Update(int elapsedTime)
{
	// Gets the current state of the keyboard
	Input::KeyboardState* keyboardState = Input::Keyboard::GetState();
	Input::MouseState* mouseState = Input::Mouse::GetState();
	if (!_startScreen)
	{
		CheckPaused(keyboardState, Input::Keys::P);
		if (!_paused)
		{
			Input(elapsedTime, keyboardState, mouseState);
			CheckViewPortCollision();
			CheckGhostCollision();
			UpdatePacman(elapsedTime);
			CheckMunchieCollision();

			for (int i = 0; i < GHOSTCOUNT; i++)
			{
				UpdateGhost(_ghosts[i], elapsedTime);
			}
			for (int i = 0; i < MUNCHIECOUNT; i++)
			{
				UpdateMunchie(_munchie[i], elapsedTime);
			}
		}
	}
	if (keyboardState->IsKeyDown(Input::Keys::SPACE) && !_spaceDown)
	{
		_spaceDown = true;
		_startScreen = !_startScreen;
	}
	if (keyboardState->IsKeyUp(Input::Keys::SPACE))
	{
		_spaceDown = false;
	}
}

void Pacman::Draw(int elapsedTime)
{
	// Allows us to easily create a string
	std::stringstream stream;
	stream << "Pacman X: " << _pacman->Position->X << " Y: " << _pacman->Position->Y;
	stream << "\nScore = " << _score;
	
	SpriteBatch::BeginDraw(); // Starts Drawing
	
	if (_score == 50)
	{
		std::stringstream menuStream;
		menuStream << "CONGRATULATIONS YOU HIT 50 POINTS";

		SpriteBatch::Draw(_menu->Background, _menu->Rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->StringPosition, Color::Green);
	}

	if (!_pacman->dead)
	{
		SpriteBatch::Draw(_pacman->Texture, _pacman->Position, _pacman->SourceRect);
	}
	
	else if (_pacman->dead)
	{
		std::stringstream menuStream;
		menuStream << "Bad Luck, your score was " << _score;

		SpriteBatch::Draw(_menu->Background, _menu->Rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->StringPosition, Color::Magenta);
	}

	int i;
	for (i = 0; i < MUNCHIECOUNT; i++)
	{
		SpriteBatch::Draw(_munchie[i]->Texture, _munchie[i]->Position, _munchie[i]->Rect);
	}
	
	SpriteBatch::Draw(_cherry->Texture, _cherry->Position, _cherry->Rect);
		
	// Draws Ghosts
	for (i = 0; i < GHOSTCOUNT; i++)
	{
		SpriteBatch::Draw(_ghosts[i]->Texture, _ghosts[i]->Position, _ghosts[i]->Rect);
	}

	// Draws String
	SpriteBatch::DrawString(stream.str().c_str(), _stringPosition, Color::Green);
	
	if (_paused)
	{
		std::stringstream menuStream;
		menuStream << "PAUSED!";

		SpriteBatch::Draw(_menu->Background, _menu->Rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->StringPosition, Color::Red);
	}
	
	if (_startScreen)
	{
		std::stringstream menuStream;
		menuStream << "Press Space To Begin";

		SpriteBatch::Draw(_menu->Background, _menu->Rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->StringPosition, Color::Blue);
	}
	SpriteBatch::EndDraw(); // Ends Drawing

}
